{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fnil\fcharset0 Calibri;\f1\fmodern\fcharset0 CourierNewPSMT;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\ri0\sl276\slmult1\sa200\partightenfactor0

\f0\fs22 \cf0 The example workbooks are available on this book\'92s website at 
\f1 \ul www.wiley.com/go/excel2019bible
\f0 \ulnone . The filenames are provided within each chapter.}